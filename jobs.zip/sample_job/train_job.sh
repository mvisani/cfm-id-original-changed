#!/bin/bash
#SBATCH --account=def-rgreiner
#SBATCH --nodes=6               # number of MPI processes
#SBATCH --ntasks-per-node=32
#SBATCH --mem=96G      # memory; default unit is megabytes
#SBATCH --time=0-12:00           # time (DD-HH:MM)
#SBATCH --mail-user=fw4@ualberta.ca
#SBATCH --mail-type=ALL

srun cfm-train ../../data_set/metlin/input_small_mol.txt ./feature_config.txt ./config.txt  ../../data_set/metlin/peakfiles 1 status.log > output.log


