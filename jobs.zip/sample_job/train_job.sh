mpirun ../../cfm/bin/cfm-train ../../data_set/metlin/input_tiny.txt ./feature_config.txt ./config.txt  ../../data_set/metlin/peakfiles 1 status.log 


