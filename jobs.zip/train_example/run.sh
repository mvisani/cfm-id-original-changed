#!/bin/bash

../../cfm/bin/cfm-train ./example_input_file.txt ./example_feature_config.txt ./example_param_config.txt  ./example_train_data.msp 1 status.log
> output.log
