
CFM-TRAIN EXAMPLE
------------------------

Command line:

cfm-train.exe example_input_file.txt example_feature_config.txt example_param_config.txt example_train_data.msp 1 status.log

Explanation:

The input file contains 3 molecules, with ids ID_3, ID_4 and ID_5. 
The corresponding reference spectra for these molecules are contained in the file example_train_data.msp.
Note that the only necessary fields in this msp file are ID, Num Peaks, and the peaks themselves. All else is ignored.
In this example, ID_3 and ID_4 are assigned to cross-fold group 0, ID_5 is assigned to cross-fold group 1 
(as indicated by the final column of example_input_file.txt).
In the command line arguments, it is specified that group 1 is to be trained for. 
This means that cfm-train will train on the molecules not in group 1 (ID_3 and ID_4), and use the resulting trained 
model to predict spectra for molecules in group 1 (i.e. ID_5). If instead, you want to train on all molecules in the 
input file, set the group argument to a number that is not assigned to any molecule (e.g. in this case, training for 
group 2 would use all three molecules).
example_feature_config.txt sets the chemical features to be used.
example_param_config.txt sets the parameters of the model to be trained.
If unsure what to do for these files, consider using one of the param_config.txt files from the existing trained_models,
selecting the model closest to the one you want to train e.g. if using EI data, select the EI one, or if using negative data, 
select the negative one.  Similarly the feature_config file can be taken by extracting the list of features from an 
existing param_output.log file and splitting the feature list over lines in a new file (see the example one used here).

Output:

As the program runs, various status information will be printed to stdout, and also written to the specified 
status file (in the example above, this is status.log).
The remainder of the output will be written to a directory called tmp_data that will be created by the program.
In this example, the details of the final trained model will be written to param_output1.log.
The spectrum predicted for ID_5 will be written to predicted_output/pspecs_P0G1.msp.
The remainder of the files and directories written to tmp_data save way-points during the run.
If you need to stop the program and re-start it for some reason under the same conditions
(e.g. due to power outage), then simply leave all these files in place and restart the program as before.
However, note that if you decide to re-run the program with different inputs or parameters, it's important
to first delete the whole tmp_data folder.

Running on multiple processors:

The cfm-train code is set up for compatibility with MPI. 
If you want to run it across multiple processors, you will need to install mpi separately and then run cfm-train from that
e.g. on windows using Windows MPI, with 3 processors:

"C:\Program Files\Microsoft MPI\Bin\mpiexec.exe" -n 3 cfm-train.exe example_input_file.txt example_feature_config.txt example_param_config.txt example_train_data.msp 1 status.log

The parallelization is fairly simple. If you run on N processors, the code will assign the input molecules to processors in the order they appear
in the input file e.g. 1st molecule to 1st processor, 2nd molecule to 2nd processor, ... N+1-th molecule to 1st processor, ...etc
Depending on your input, it may be worth re-ordering the molecules in your input file to try to assign roughly equal loads to each processor.
e.g. if you run cfm-train on the input initially until all the fragmentation graphs are computed, and then stop it once the EM starts,
status.log should then record how long it took to compute the graph for each molecule.
You could then reorder the input molecules in order of increasing or decreasing time for computation to get a roughly balanced load.
The predicted spectra for each processor will be written to a different msp file.


















